//
//  Framework for a raytracer
//  File: scene.cpp
//
//  Created for the Computer Science course "Introduction Computer Graphics"
//  taught at the University of Groningen by Tobias Isenberg.
//
//  Authors:
//    Maarten Everts
//    Jasper van de Gronde
//
//  This framework is inspired by and uses code of the raytracer framework of 
//  Bert Freudenberg that can be found at
//  http://isgwww.cs.uni-magdeburg.de/graphik/lehre/cg2/projekt/rtprojekt.html 
//

#include "scene.h"
#include "sphere.h"
#include "material.h"
#define abs(x) (x) <= 0.0 ? -(x) : (x)

Color Scene::trace(const Ray &ray)
{
    // Find hit object and distance
    
    Hit min_hit(std::numeric_limits<double>::infinity(),Vector());
    Object *obj = NULL;
    for (unsigned int i = 0; i < objects.size(); ++i) {
        Hit hit(objects[i]->intersect(ray));
        if (hit.t<min_hit.t) {
            min_hit = hit;
            obj = objects[i];
        }
    }
    
    // No hit? Return background color.
    if (!obj) return Color(0.0, 0.0, 0.0);
    else if(renderMode.compare("phong") == 0)
    {  
        

        Material *material = obj->material;            //the hit objects material
        Point hit = ray.at(min_hit.t);                 //the hit point
        Vector N = min_hit.N;                          //the normal at hit point
        Vector V = -ray.D;                             //the view vector

        /****************************************************
        * This is where you should insert the color
        * calculation (Phong model).
        *
        * Given: material, hit, N, V, lights[]
        * Sought: color
        *
        * Hints: (see triple.h)
        *        Triple.dot(Vector) dot product
        *        Vector+Vector      vector sum
        *        Vector-Vector      vector difference
        *        Point-Point        yields vector
        *        Vector.normalize() normalizes vector, returns length
        *        double*Color        scales each color component (r,g,b)
        *        Color*Color        dito
        *        pow(a,b)           a to the power of b
        ****************************************************/
        //Diffuse and ambient only
        /*Color c;
        for(unsigned int i = 0; i < lights.size(); ++i){
          Vector L = (lights[i]->position - hit).normalized(); 
          double component = (max(0.0, N.dot(L)));
          Vector ambient = material->ka*lights[i]->color;
          c += ambient + (lights[i]->color * component * material->kd);
        }
        return c * material->color;*/
        
        //Diffuse, ambient and specular
        Color c;
        
        Vector specular(0.0,0.0,0.0);
        for(unsigned int i = 0; i < lights.size(); ++i){
          Vector L = (lights[i]->position - hit).normalized(); 
          double component = (max(0.0, N.dot(L)));
          Vector ambient = material->ka*lights[i]->color;
          Vector R = 2.0*(N.dot(L))*N - L;
          if(V.dot(R) > 0.0)
            specular += material->ks * lights[i]->color * pow(V.dot(R), material->n); 
           
          c += ambient + (lights[i]->color * component * material->kd);
        }
        return c * material->color + specular;
    }
    
    else if(renderMode.compare("zbuffer") == 0)
    {
        double scaled = 1.0 - ((min_hit.t) - minZ) / (maxZ - minZ);
        return Color(scaled,scaled,scaled);
    }
    
    else if(renderMode.compare("normal") == 0)
    {
        return (min_hit.N  + 1.0) / 2.0;
    }
    else return Color(0.0,0.0,0.0);
}

void Scene::render(Image &img)
{
    int w = img.width();
    int h = img.height();
    //In case of z buffer, determine minimum and maximum distance from eye first
    if(renderMode.compare("zbuffer") == 0)
    {
        double minHit = std::numeric_limits<double>::infinity();
        double maxHit = -std::numeric_limits<double>::infinity();
        for (int y = 0; y < h; y++) {
          for (int x = 0; x < w; x++) {
              Point pixel(x+0.5, h-1-y+0.5, 0);
              Ray ray(eye, (pixel-eye).normalized());
              for (unsigned int i = 0; i < objects.size(); ++i) {
                  Hit hit(objects[i]->intersect(ray));
                  if (hit.t<minHit) 
                      minHit = hit.t;
                  if(hit.t > maxHit)
                      maxHit = hit.t;
              }
          }
       }
       minZ = minHit;
       maxZ = maxHit;
    }
      
    cout << objects.size() << endl;
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            Point pixel(x+0.5, h-1-y+0.5, 0);
            Ray ray(eye, (pixel-eye).normalized());
            Color col = trace(ray);
            col.clamp();
            img(x,y) = col;
        }
    }
}
void Scene::addObject(Object *o)
{
    objects.push_back(o);
}

void Scene::addLight(Light *l)
{
    lights.push_back(l);
}

void Scene::setEye(Triple e)
{
    eye = e;
}

void Scene::setRenderMode(std::string s)
{
    renderMode = s;
}
