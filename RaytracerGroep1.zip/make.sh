make && ./ray $1.yaml && shotwell $1.png
